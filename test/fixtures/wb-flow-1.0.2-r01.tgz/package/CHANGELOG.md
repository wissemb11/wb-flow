# Changelog

All notable changes to this project will be documented in this file.

## [1.0.2-r01] - 2026-07-30

### `wb-flow init` — assistant wiring, no longer by hand

Until now the CLI copied the command *templates* and stopped there. Registering
`/wbPlan` in an assistant was undocumented manual work — a wrapper file per
command per assistant, in each one's own format and location. `wb-flow init`
does it.

#### 🔌 Added
- **`wb-flow init`** — interactive setup (zero-dep `readline` prompts) that asks
  for a scope and which assistants to wire, then copies the templates *and*
  writes the command files.
  - **Claude Code** / **OpenCode** / **Cursor** → `<cmd>.md` with `description`
    frontmatter and `$ARGUMENTS`.
  - **Gemini CLI** → `<cmd>.toml` with `description` + `prompt` and `{{args}}`.
  - **Antigravity (`agy`)** → one `wb-flow/SKILL.md` dispatcher. Antigravity has
    no user-definable slash-commands (only Rules, Skills, Plugins, Hooks, MCP),
    so its commands are invoked in natural language: `run wbPlan on src/`.
  - Scopes: `global` copies templates to `~/.wb-flow/` and embeds absolute paths;
    `project` copies to `./.wb/` and embeds relative paths so the wiring can be
    committed and shared with a team.
  - Installed assistants are auto-detected and default to Yes.
  - Flags: `--scope=`, `--agents=` (list / `all` / `detected` / `none`),
    `--templates=`, `--yes`, `--force`, `--dry-run`, `--help`. Non-destructive by
    default; in a non-TTY `--yes` is required so CI can never hang on a prompt.
- **`bin/wrappers.js`** — the emitters as importable pure functions, driven by
  `wb_commands_reference.claude.json` (description, recommended model, real flag
  lists, `--act`/`--wbPlan` chaining). Normalizes the three different flag shapes
  the manifest uses. Alias commands (`wbStopTrack`) resolve to their target
  template.
- **`--version` / `-v`** on the main CLI.
- 40 new assertions covering the emitters and init end-to-end (dry-run writes
  nothing, both scopes, idempotent re-runs, TOML structure, non-TTY refusal,
  unknown-agent rejection). Suite: 71 → 111.

#### 🌊 Added — wave scheduling
- **`## 🌊 Next Executable Sequence`** — every plan (and audit / review / standup /
  secure / next / idea / actOn output) now ends with a **wave × role matrix**:
  rows are parallel-safe waves, columns are the four `Requires` roles, each cell
  a copy/paste command with a recommended agent and cost. Canonical spec in
  `_shared/output_conventions.md` §10; `/wbPlan` is the reference implementation
  (template v5.3).
  - **Waves come from the dependency DAG, not priority** — a P1 task with an
    unmet dependency is not in wave A.
  - **Every dispatch is auto-paired** with `/wbValid <same id>` in the next wave,
    assigned to a **different agent than the executor** (§10.2 rule 10). A model
    validating its own work is the main way a hollow pass reaches a plan file.
  - **Mandatory collision check** per parallel row, including files one cell
    writes and another reads as a fixture.
  - **The matrix is derived state** (§10.4): `/wbWork`, `/wbValid` and
    `/wbPlan --id=… --open/--def/--can` each recompute it in the same pass they
    touch a Done/Valid box. A matrix older than the last `/wbWork` run is lying.
- **`wb-flow wave <plan.md> --wave=A`** — compiles one row of the matrix into a
  bash script: one background job per cell, per-cell logs, exit code = number of
  failed cells. `--list` shows the resolved routing first; `--print` dumps the
  script without writing it. Routing: 🧠 Planner → the orchestrator in-session ·
  🔨 Worker → `opencode-go/deepseek-v4-pro` · 📋 Mechanical →
  `opencode-go/deepseek-v4-flash` · ✅ Validator → in-session, or
  `opencode-go/kimi-k2.7-code` when it pairs a row the orchestrator itself ran.
- **`/wbWork --wave=<label>`** — the orchestration mode that drives the above.
- **`--no-plan-update`** on `/wbWork` and `/wbValid` — execute and write the task
  report, but never touch the plan file. Set automatically for every spawned
  agent, because *N* parallel agents doing read-modify-write on one markdown
  table corrupts it. The orchestrator checks the boxes and recomputes the matrix
  once, after the wave settles, and only for cells that actually succeeded.

#### 🏃 Added — `wbRun` subshell error guard
- **`.wb/bin/wbRun`** — zero-dependency subshell wrapper that inspects stdout/stderr
  for fatal patterns (`^Error: Insufficient credits`, `^Error: Model not found`,
  etc.) instead of relying on exit codes alone. Displays `▶ Executing: <cmd>`
  banners and fails over to the next model in a `||` chain. Installed by
  `bin/init.js` into the consumer project's `.wb/bin/`.
- **Native wave integration** — `bin/wave.js` wraps every background worker
  dispatch with `$WB_RUN`, so a `Model not found` or credit exhaustion in any
  cell triggers fallback instead of silently succeeding on a zero exit code.

#### 🎛️ Added — per-role model override flags
- **`--planner="<models>"` / `--validator="<models>"` / `--worker="<models>"` /
  `--mechanical="<models>"`** — dynamic CLI flags on `/wbWork`, `/wbPlan`, and
  `/wbModel` that set the model fallback chain (`1st,2nd`) for each role.
  Precedence: explicit flag > plan-header roster > `model_recommendations.md` >
  `DEFAULT_MODELS`. `--list` reports the resolved source.

#### 📋 Added — plan model roster & matrix auto-correction
- **`> **Active Model Roster for this Plan:**`** header block under
  `## 🌊 Next Executable Sequence` — persists the configured model roster in
  every plan file so the wave generator resolves models from the plan itself
  before falling back to the manifest or built-in defaults.
- **Matrix auto-correction** — if a plan file is missing the
  `## 🌊 Next Executable Sequence` section, `/wbPlan` and `/wbWork` automatically
  repair/generate it before execution.

#### 🧰 Added — `/wbModel` command & 9-file documentation suite
- **`/wbModel`** — view and override role model rosters
  (e.g. `/wbModel --validator="DSV4 pro"`).
- **Standardized 9-file documentation suite** — every command directory under
  `docs/commands/wb<Command>/` now carries the same 9-file set (README, spec,
  ELI5, examples ×2, exhaustive simulation, expert, live demo, practical):
  33 commands × 9 files = 297 doc files + 33 READMEs.

#### 🔧 Changed
- `--help` now documents the `init` subcommand and states plainly that a bare
  `wb-flow` run does **not** register slash-commands in any assistant.
- **Unknown positional arguments now error** instead of being silently ignored.
  Previously `wb-flow init` (and any typo) fell through to a plain install; that
  also meant `wb-flow --version`, which the docs recommended as a verification
  step, quietly installed templates into the current directory.

## [1.0.1] - 2026-05-14

### Official Stable Release

This release marks the transition from beta (`1.0.0-r01`) to the first official stable version. The CLI itself is unchanged — the focus is on documentation, discoverability, and developer experience.

#### 🚀 Documentation Website Launched
- **`flow.wbc-ui.com`** — Full VitePress-powered documentation site deployed.
- Per-page SEO metadata (title, description, Open Graph, Twitter Cards) for every doc page.
- Static workflow diagrams + 16 interactive Mermaid diagram equivalents embedded in GitHub docs.
- Google Analytics 4 (`G-RDGRR88KJH`) + Umami (ready) for traffic tracking.

#### 📚 GitHub Documentation Overhaul
- Added per-page frontmatter (title + description) to 60+ markdown files.
- Copied wb-flow logo and static workflow diagrams for native GitHub rendering.
- Added **Live Reports Snapshot** (`concepts/live_reports_snapshot.md`) showing real `.wb/workflows/` output.
- Added 16 Mermaid.js diagrams matching the Vue animation color palette (Plan/Work/Valid/Teal roles).
- Wrapped all diagrams in width-constrained containers for clean mobile rendering.
- Fixed 7 broken internal links; verified all 1,637 internal links clean.
- Added demo apps section with `python-etl` worked example.

#### 🔍 Analytics & SEO
- GA4 stream configured (`G-RDGRR88KJH`) for website traffic monitoring.
- SEO metadata: Open Graph, Twitter Cards, canonical URLs, favicons.
- Umami self-hosted analytics (VPS) ready for deployment alongside GA4.

#### 📋 Full Demo Apps Added
- `demo_apps/python-etl/README.md` — Complete end-to-end ETL workflow example with real `/wbAudit`, `/wbPlan`, and `/wbSetup` outputs.

## [1.0.0-r01] - 2026-05-12

### Initial Release
- **Zero-Dependency CLI:** Instant bootstrap via `npx wb-flow` without polluting your node_modules.
- **33 `wb*` Command Templates:** Full suite of workflow templates injected directly into your `.wb/` directory.
- **Multi-AI-Host Support:** Built-in parity for Claude Code, OpenCode, Gemini, and Cursor agents.
- **Ideas Pipeline:** Enforces deterministic multi-step processes via `/wbAudit` → `/wbPlan` → `/wbWork` → `/wbValid`.
- **Four Install Paths:** Supports global, local (npx), and offline/git-clone installation methods.
- **Agentic Documentation Suite:** Includes a complete 250+ file documentation system covering all 33 commands, session tracking, and workflow concepts (shipped in `docs/`).
