# Model Recommendations per `/wb*` Command

> **Date:** 2026-07-31 (updated — default baseline reset point)
> **Based on:** Go + Zen + Google One + Claude Pro + Kimi / Moonshot + ChatGPT / OpenAI Codex

---

## User Models (Active Contractual Reference)

> **Contract:** This table represents the active model selections and CLI dispatches for `wb-flow` execution and all `/wb*` commands. Each role defines **3 priority models** executed in chain using the `||` (Bash OR fallback) operator with output-error guarding across their designated CLI utilities (`claude` for Claude Pro, `agy` for Google Gemini, `opencode` for GO/DeepSeek/Kimi/Qwen/GLM).

| Role | Active Selected Models (1st / 2nd / 3rd) | Assigned Tiers | Active CLI Invocation (Bash with `||` fallback) |
|---|---|---|---|
| 🧠 **Planner** | **Claude (auto)** / **Kimi K2.7 Code** / **GLM-5.2** | Pro / Go / Go | `.wb/bin/wbRun claude -p --permission-mode auto "<prompt>" || .wb/bin/wbRun opencode run -m opencode-go/kimi-k2.7-code --dangerously-skip-permissions "<prompt>" || .wb/bin/wbRun opencode run -m opencode-go/glm-5.2 --dangerously-skip-permissions "<prompt>"` |
| ✅ **Validator** | **Claude (auto)** / **Kimi K2.7 Code** / **GLM-5.2** | Pro / Go / Go | `.wb/bin/wbRun claude -p --permission-mode auto "/wbValid <plan.md> --id=1" || .wb/bin/wbRun opencode run -m opencode-go/kimi-k2.7-code --dangerously-skip-permissions "/wbValid <plan.md> --id=1" || .wb/bin/wbRun opencode run -m opencode-go/glm-5.2 --dangerously-skip-permissions "/wbValid <plan.md> --id=1"` |
| 🔨 **Worker** | **Gemini 3.1 Pro** / **Gemini 3.6 Flash** / **Claude (auto)** | G-One / G-One / Pro | `.wb/bin/wbRun agy -p --model gemini-3.1-pro-high --dangerously-skip-permissions "/wbWork <plan.md> --id=1" || .wb/bin/wbRun agy -p --model gemini-3.6-flash-high --dangerously-skip-permissions "/wbWork <plan.md> --id=1" || .wb/bin/wbRun claude -p --permission-mode auto "/wbWork <plan.md> --id=1"` |
| 📋 **Mechanical** | **Gemini 3.6 Flash** / **Gemini 3.1 Pro** / **Claude (auto)** | G-One / G-One / Pro | `.wb/bin/wbRun agy -p --model gemini-3.6-flash-high --dangerously-skip-permissions "/wbTest <target>" || .wb/bin/wbRun agy -p --model gemini-3.1-pro-high --dangerously-skip-permissions "/wbTest <target>" || .wb/bin/wbRun claude -p --permission-mode auto "/wbTest <target>"` |

> **Roster change (2026-08-01 09:35 — `/wbModel`):** 🔨 Worker and 📋 Mechanical moved to the **`agy`** CLI (Gemini 3.1 Pro → Gemini 3.6 Flash → Claude auto) because the `opencode-go` provider was unreachable (three models, three 30–90s timeouts on a trivial probe). Requested `gemini 4.5 pro` / `gemini 4.1 pro` **do not exist** — `agy models` tops out at `gemini-3.1-pro-high` and `gemini-3.6-flash-high`; the real ids are used here so dispatches resolve. ⚠️ This routes `/wbWork` rows to Antigravity, which was marked untrusted as a worker on 2026-07-25 (nine rows ticked Done with zero task reports). Verify its output rather than accepting Done boxes.

> **Validation note (2026-07-31):** Every `opencode-go/*` slug in this file is verified against `opencode models` output. The canonical source of truth is the live model list — run `opencode models | grep "^opencode-go/"` to re-check. If a slug drifts (e.g. a provider renames a model), the dispatch will fail with `Model not found`; fix the slug here to match.

---

## The Logic

| Role | What it needs | 🏆 Top 3 (best, regardless of budget) | Budget sweet spot | Bash (with `||` fallback) |
|---|---|---|---|---|
| 🧠 **Planner** | Deep reasoning, strategy, multi-step decomposition | Claude (auto) / Kimi K2.7 Code / GLM-5.2 | Claude (auto) | `.wb/bin/wbRun claude -p --permission-mode auto "<prompt>" || .wb/bin/wbRun opencode run -m opencode-go/kimi-k2.7-code --dangerously-skip-permissions "<prompt>" || .wb/bin/wbRun opencode run -m opencode-go/glm-5.2 --dangerously-skip-permissions "<prompt>"` |
| ✅ **Validator** | **Big Thinker**: Deep reasoning, code quality judgment, score | Claude (auto) / Kimi K2.7 Code / GLM-5.2 | Claude (auto) | `.wb/bin/wbRun claude -p --permission-mode auto "/wbValid <plan.md> --id=1" || .wb/bin/wbRun opencode run -m opencode-go/kimi-k2.7-code --dangerously-skip-permissions "/wbValid <plan.md> --id=1" || .wb/bin/wbRun opencode run -m opencode-go/glm-5.2 --dangerously-skip-permissions "/wbValid <plan.md> --id=1"` |
| 🔨 **Worker** | Coder/executor: code generation, file edits | DeepSeek V4 Pro / Gemini 3.1 Pro / Claude (auto) | DeepSeek V4 Pro | `.wb/bin/wbRun opencode run -m opencode-go/deepseek-v4-pro --dangerously-skip-permissions "/wbWork <plan.md> --id=1" || .wb/bin/wbRun agy -p --model gemini-3.1-pro-high --dangerously-skip-permissions "/wbWork <plan.md> --id=1" || .wb/bin/wbRun claude -p --permission-mode auto "/wbWork <plan.md> --id=1"` |
| 📋 **Mechanical** | Run command, read output, format report | Qwen 3.7 Plus / DeepSeek V4 Pro / Gemini 3.1 Pro | Qwen 3.7 Plus | `.wb/bin/wbRun opencode run -m opencode-go/qwen3.7-plus --dangerously-skip-permissions "/wbTest <target>" || .wb/bin/wbRun opencode run -m opencode-go/deepseek-v4-pro --dangerously-skip-permissions "/wbTest <target>" || .wb/bin/wbRun agy -p --model gemini-3.1-pro-high --dangerously-skip-permissions "/wbTest <target>"` |

---
